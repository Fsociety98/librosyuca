@extends('layouts.adminLayout')
@section('content')
<div class="container-fluid">
    <h1 class="mt-4">Autores</h1>
</div>
@endsection
