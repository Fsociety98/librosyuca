
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="mt-4">Autores</h1>
        <?php echo $__env->make('autores.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Foto</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($autor->nombre); ?></td>
                    <td>
                        <!-- <img src="<?php echo e(asset('storage').'/'.$autor->foto); ?>" />-->
                    </td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(url('/autores/'.$autor->autorId.'/edit')); ?>">
                            Editar
                        </a>          
                    </td>
                    <td>
                        <form action="<?php echo e(url('/autores/'.$autor->autorId)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button class="btn btn-danger" type="submit" onclick="return confirm('¿Borrar?');">Borrar</button>
                        </form>
                    </td>
                <tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\librosyuca\resources\views/autores/index.blade.php ENDPATH**/ ?>