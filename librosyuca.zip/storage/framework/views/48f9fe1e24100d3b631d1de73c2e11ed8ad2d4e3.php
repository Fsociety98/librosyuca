
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="mt-4">Clasificaciones</h1>
    <?php echo $__env->make('clasificaciones.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($clasificacion->nombre); ?></td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(url('/clasificaciones/'.$clasificacion->clasificacionId.'/edit')); ?>">
                            Editar
                        </a>          
                    </td>
                    <td>
                        <form action="<?php echo e(url('/clasificaciones/'.$clasificacion->clasificacionId)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button class="btn btn-danger" type="submit" onclick="return confirm('¿Borrar?');">Borrar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\librosyuca\resources\views/clasificaciones/index.blade.php ENDPATH**/ ?>