

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-defoult">
                <h1 class="panel-title">
                    Acceso a la aplicación
                </h1>
                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group <?php echo e($errors->has('email') ? 'is-invalid':''); ?>">
                            <label for="email">email</label>
                            <input class="form-control"
                             type="email" 
                             name="email" 
                             placeholder="Ingresa tu email">
                             <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('password') ? 'is-invalid':''); ?>">
                            <label for="password">Contraseña</label>
                            <input class="form-control"
                             type="password" 
                             name="password" 
                             placeholder="Ingresa tu contraseña">
                             <?php echo $errors->first('password','<span class="help-block">:message</span>'); ?>

                        </div>
                        <button class="btn btn-primary btn-block">
                            Acceder
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\librosyuca\resources\views/login.blade.php ENDPATH**/ ?>