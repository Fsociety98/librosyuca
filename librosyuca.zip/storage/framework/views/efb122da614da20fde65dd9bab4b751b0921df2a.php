
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="mt-4">Autores</h1>
     <form action="<?php echo e(url('/autores/'.$autor->autorId)); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PATCH')); ?>

    <div class="form-group row">
        <label for="email" class="col-md-4 col-form-label text-md-right">Nombre del autor</label>
        <div class="col-md-6">
            <input id="email" type="text" class="form-control" name="nombre" value="<?php echo e($autor->nombre); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Editar</button>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\librosyuca\resources\views/autores/edit.blade.php ENDPATH**/ ?>