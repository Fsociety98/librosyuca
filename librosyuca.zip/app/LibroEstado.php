<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LibroEstado extends Model
{
    //
}
